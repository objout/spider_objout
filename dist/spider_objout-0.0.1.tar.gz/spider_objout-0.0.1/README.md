- 300条url爬取
    * set-cookie
    * window.__pinia
    * 多页面抓取
    * gzip 解压
- 针对每条url, 弹幕爬取(获得cid, 替换oid)
    - https://api.bilibili.com/x/v2/dm/wbi/web/seg.so?type=1&oid=1196257131&pid=445934810&segment_index=1&pull_mode=1&ps=0&pe=120000&web_location=1315873&w_rid=d36f19cf6bf2a5183098dba274bf0a74&wts=1694001541
    - https://api.bilibili.com/x/v2/dm/wbi/web/seg.so?type=1&oid=1196257131&segment_index=1&pull_mode=1&ps=0&pe=120000&web_location=1315873&w_rid=817c4e923a746e54055fd7af79eed03b
    - https://api.bilibili.com/x/v2/dm/wbi/web/seg.so?type=1&oid=1196257131&segment_index=1&pull_mode=1&ps=0&pe=120000
- seg.so解析


## `seg.so` 文件解析

Reference:
- [csdn.net](https://blog.csdn.net/qq_39870538/article/details/124352010)
- [github.com](https://github.com/SocialSisterYi/bilibili-API-collect/blob/bb437d2012e6291b38c78d42755db9d836d4975f/grpc_api/bilibili/community/service/dm/v1/dm.proto)
- [protogen.marcgravell.com](https://protogen.marcgravell.com/#)

### protobuf 介绍

- Protocol buffer
- Google内部混合语言数据标准
- 将结构化数据进行序列化(串行化)
-用于通讯协议、数据存储等领域的语言无关、平台无关、可扩展的
序列化结构数据格式.

### Python中的使用

```bash
pip3 install protobuf
```

Procedure:
- 将Github上的API接口复制到protogen生成Python代码.
- 保存此Python代码为`bili_pb2.py`, 以`_pb2.py`结尾.

```python
import bili_pb2 # 同一目录
import re
from google.protobuf import text_format

with open('./seg.so', 'rb') as f:
    DATA = f.read()

my_seg = bili_pb2.DmSegMobileReply()
my_seg.ParseFromString(DATA)
reg = '.*?content:.*?"(.*?)".*?ctime.*?' # 过滤内容
p = re.compile(reg, re.S)
for j in my_seg.elems:
    parse_data = text_format.MessageToString(j, as_utf8=True)
    print(p.findall(parse_data))
```
